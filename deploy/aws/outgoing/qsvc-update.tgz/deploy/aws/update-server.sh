#!/bin/bash
# Runs ON the EC2 backend (as root, e.g. from Session Manager). Applies an overlay update to /opt/qsvc.
#   bash update-server.sh /path/to/qsvc-update.tgz [/path/to/installer-parts-dir]
# Keeps deploy/aws/.env and existing data; backs up every file it replaces.
set -euo pipefail
ARCHIVE=${1:?Give the update archive path}
PARTS=${2:-}
ROOT=/opt/qsvc
COMPOSE="docker compose -f deploy/aws/compose.yml --env-file deploy/aws/.env"
STAMP=$(date -u +%Y%m%dT%H%M%SZ)
BACKUP=/opt/qsvc-backups/$STAMP
envval() { grep -E "^$1=" "$ROOT/deploy/aws/.env" | tail -1 | cut -d= -f2- ; }
say() { printf '\n== %s\n' "$*"; }

cd "$ROOT"
say "1/7 Back up files that will be replaced -> $BACKUP"
mkdir -p "$BACKUP"
tar tzf "$ARCHIVE" | grep -v '/$' > "$BACKUP/files.txt"
while read -r f; do [ -f "$f" ] && { mkdir -p "$BACKUP/$(dirname "$f")"; cp -p "$f" "$BACKUP/$f"; }; done < "$BACKUP/files.txt"
cp -p deploy/aws/.env "$BACKUP/env.backup"; chmod 600 "$BACKUP/env.backup"
echo "backed up $(find "$BACKUP" -type f | wc -l) files"

say "2/7 Apply update ($(wc -l < "$BACKUP/files.txt") files)"
tar xzf "$ARCHIVE" -C "$ROOT" --no-same-owner
if [ -n "$PARTS" ] && ls "$PARTS"/QS-VC-Windows-Setup.exe.part* >/dev/null 2>&1; then
  install -d -m 0755 deploy/aws/installers
  cat "$PARTS"/QS-VC-Windows-Setup.exe.part* > deploy/aws/installers/QS-VC-Windows-Setup.exe.new
  if [ -f "$PARTS/QS-VC-Windows-Setup.exe.sha256" ] && [ "$(sha256sum deploy/aws/installers/QS-VC-Windows-Setup.exe.new | cut -d' ' -f1)" = "$(cat "$PARTS/QS-VC-Windows-Setup.exe.sha256")" ]; then
    mv deploy/aws/installers/QS-VC-Windows-Setup.exe.new deploy/aws/installers/QS-VC-Windows-Setup.exe
    chmod 0644 deploy/aws/installers/QS-VC-Windows-Setup.exe; echo "Windows installer installed (checksum OK)"
  else rm -f deploy/aws/installers/QS-VC-Windows-Setup.exe.new; echo "WARNING: installer checksum mismatch; kept the previous installer"; fi
fi

say "3/7 Settings"
grep -q '^QSVC_ADMIN_EMAILS=' deploy/aws/.env || echo 'QSVC_ADMIN_EMAILS=services@madylabs.xyz,contact@neurqai.com,smrita.official@gmail.com' >> deploy/aws/.env
grep -q '^QSVC_ADMIN_WORKSPACE_URL=' deploy/aws/.env || echo "QSVC_ADMIN_WORKSPACE_URL=$(envval WEB_URL | sed 's#/*$#/#')" >> deploy/aws/.env
chmod 600 deploy/aws/.env
echo "QSVC_ADMIN_WORKSPACE_URL=$(envval QSVC_ADMIN_WORKSPACE_URL)"

say "4/7 Build images (several minutes on this host)"
$COMPOSE build auth web 2>&1 | tail -5

say "5/7 Database migrations"
MIGRATION_URL=$(envval MIGRATION_DATABASE_URL || true)
if [ -n "$MIGRATION_URL" ]; then
  $COMPOSE --profile maintenance run --rm migrate 2>&1 | tail -12
  ADMIN_DB_ENV=()
else
  echo "MIGRATION_DATABASE_URL is empty: migrations NOT run. Add it privately to deploy/aws/.env and re-run this script."
  ADMIN_DB_ENV=(-e "DATABASE_URL=$(envval AUTH_DATABASE_URL)")
fi

say "6/7 Platform admin accounts"
if [ -f "$ROOT/deploy/aws/admin-password.hash" ]; then
  $COMPOSE --profile maintenance run --rm "${ADMIN_DB_ENV[@]}" \
    -e QSVC_ADMIN_PASSWORD_HASH_FILE=/opt/qsvc/admin-password.hash \
    -v "$ROOT/deploy/aws/admin-password.hash:/opt/qsvc/admin-password.hash:ro" \
    migrate node services/auth/scripts/create-platform-admins.cjs 2>&1 | tail -6 || echo "Admin script failed (see above)"
  shred -u "$ROOT/deploy/aws/admin-password.hash" 2>/dev/null || rm -f "$ROOT/deploy/aws/admin-password.hash"
else echo "No admin-password.hash in the update; skipped"; fi

say "7/7 Restart services and check"
$COMPOSE up -d 2>&1 | tail -12
sleep 25
for p in 4002 4003; do printf 'port %s ready: ' "$p"; curl -s -m 5 "http://127.0.0.1:$p/ready" || echo "NOT READY"; echo; done
printf 'reserved admin sign-up refused (new code live): '
curl -s -m 5 -o /dev/null -w '%{http_code}\n' -X POST http://127.0.0.1:4002/api/auth/register -H 'Content-Type: application/json' -d '{"email":"contact@neurqai.com","password":"not-a-real-pass-123","displayName":"x"}'
$COMPOSE ps --format 'table {{.Service}}\t{{.Status}}' 2>/dev/null || $COMPOSE ps
echo "Rollback: copy files back from $BACKUP (and $BACKUP/env.backup to deploy/aws/.env), then: $COMPOSE build auth && $COMPOSE up -d"
